from tkinter import *
import os
from Clases_y_objetos import * 
from CocinaRestauranteVolador import *
from CocinaRestauranteFrances import *
from CocinaRestauranteEnLaCosta import *

"""-----------------------------------------------------------------------------------------"""

def cargarImagen(nombre):
    #Esta funcion se encargara de crear una ruta para la imagen de fonfo para la pantalla de inicio
    ruta=os.path.join("imagenes",  nombre)
    imagen=PhotoImage(file=ruta)
    return imagen

"""-----------------------------------------------------------------------------------------"""

def pantallaDeSeleccionMap():
    PerFrame=Frame() #Crea un nuevo frame 
    PerFrame.pack(fill=BOTH, expand=True) #Expande el frame para que se pueda ver en pantalla

    fotoFondo=cargarImagen("FondoMapa.png") #Carga la images desde la ruta creada al inicio
    fotoFondo=fotoFondo.zoom(2, 1)  # agranda la imagen al doble
    labelFondo=Label(PerFrame, image=fotoFondo) #crea la imagen como una especie de etiqueta
    labelFondo.place(relx=0.5, rely=0.5, anchor="center") #Posiciona la imagen
    labelFondo.lower() #Envia la imagen al fondo del escenario, evitando que tape a las demas
    labelFondo.image = fotoFondo 
    import Interfaz_grafica_inicio #Esto sera para importar la variable de PuntosAcumulados
    
    labelPuntos = Label(PerFrame, text=f"Puntos totales: {Interfaz_grafica_inicio.PuntosAcumulados}")
    labelPuntos.config(bg="grey")
    labelPuntos.place(x=1050, y=0)
    """--------------------------------------------------------------------------------------"""
    
    #Botones para elegir el nivel:
    def RestauranteVolador():
        PerFrame.pack_forget()
        Cocina1Volador()
    botonRestauranteVolador= Button(PerFrame, text="Restaurante Volador", command=RestauranteVolador) #Se crea el boton PLAY
    botonRestauranteVolador.place(relx=0.7, rely=0.3, anchor="center")
    
    def RestauranteFrances():
        PerFrame.pack_forget()
        Cocina2Frances()
    botonRestauranteFrances=Button(PerFrame, text=("Restaurante Frances"), command=RestauranteFrances)
    botonRestauranteFrances.place(relx=0.4, rely=0.3, anchor="center")
    
    def RestauranteCosta():
        PerFrame.pack_forget()
        Cocina3Costa()
    botonRestauranteCosta=Button(PerFrame, text=("Restaurante en la costa"), command=RestauranteCosta) 
    botonRestauranteCosta.place(relx=0.6, rely=0.7, anchor="center")





    