"""Aqui se guardaran las clases principales que pide el documento del proyecto,
ademas son las que estan en el principal diagrama UML. Entre cada clase se pondra una linea 
de guiones para que se vea mas ordenado el codigo"""

import random
import time
import tkinter

class Ingrediente():
    #Al ser que los ingredientes tienen el mismo formato, se crea una clase padre con el siguiente cosntructor
    def __init__(self, nombre, estado):
        self.nombre = nombre #string
        self.estado = estado #bool

"""--------------------------------------------------------------------------------------------------------"""

class Vegetales_Y_Frutas(Ingrediente):
    #Hija de la clase Ingredinete, posee un metodo que cambia el estado del ingrediente a True
    def __init__(self, nombre, estado=False):
        super().__init__(nombre, estado)

    def cortar(self):
        self.estado = True

"""--------------------------------------------------------------------------------------------------------"""

class Panes_Y_Bases(Ingrediente):
    #Hija de la clase Ingredinete, posee un metodo que cambia el estado del ingrediente a True
    def __init__(self, nombre, estado=False):
        super().__init__(nombre, estado)

    def cocinar(self):
        self.estado = True

"""--------------------------------------------------------------------------------------------------------"""

class Proteinas(Ingrediente):
    #Hija de la clase Ingredinete, posee un metodo que cambia el estado del ingrediente a True
    def __init__(self, nombre, estado=False):
        super().__init__(nombre, estado)
        
    def freir(self):
        self.estado = True

"""--------------------------------------------------------------------------------------------------------"""

class Receta():
    """La clase receta se encanrga de guardar la lista de obtejos Ingrediente, los puntos que da la receta y el tiempo
    maximo para hacerla, ademas de tener un metodo para comparar la receta con una lista de ingredientes dada y 
    otro metodo para comparar el tiempo dado con el tiempo maximo de la receta"""
    def __init__(self, listaIngredientes, puntosReceta, maxTimeReceta):
        self.listaIngredientes = listaIngredientes #List de objetos Ingrediente
        self.puntosReceta = puntosReceta #int
        self.maxTimeReceta = maxTimeReceta #int

    def comparaReceta(self, ingredientes):
        #Compara si las recetas son iguales
        if len(ingredientes) != len(self.listaIngredientes): #Empieza comparando la cantidad de ingredientes 
            return False
        #Esto compara los nombres de los ingredientes que se entregan sin importar el orden
        nombreEntregados=sorted([ing.nombre for ing in ingredientes])
        nombreReceta=sorted([ing.nombre for ing in self.listaIngredientes])
        estadosEntregados=([ing.estado for ing in ingredientes])
        
        #Este de paso verifica que todos esten en estado True
        if not all(estadosEntregados):
            return False
        return nombreEntregados==nombreReceta
    
    def TiempoLimite(self, tiempo):
        #Si el timepo dado es menor o igual al tiempo maximo de la receta, devuelve la mitad de los puntos de la receta, sino devuelve 0
        if tiempo <= self.maxTimeReceta:
            self.puntosReceta//=2 #aqui divide los puntos de la receta
            if self.puntosReceta <=0: #aqui establece un minimo de puntos que es cero
                self.puntosReceta =0
              

"""--------------------------------------------------------------------------------------------------------"""
class Player():
    #Esta clase posee tres atributos, el nombre del jugador, el ingrediente que lleva consigo y los puntos que posee, los cuales siempore inician en cero
    def __init__(self, nombre, Ingrediente=None, x=0, y=0):
        self.nombre = nombre #string
        self.puntos = 0 #int
        self.Ingrediente = Ingrediente #Un objeto Ingrediente
        self.x = x
        self.y = y
        self.face = "abajo"

    def setNombre(self, newnombre): #Otorga un nuevo nombre al objeto
        self.nombre=newnombre
    
    def setX(self,x): #Otorga una nueva posicion
        self.x=x
    
    def setY(self, y): #Otorga una nueva posicion 
        self.y=y
    
    def getPuntos(self): #Obtiene los puntos
        return self.puntos
    
    def UnIngrediente(self, ingrediente):
        #Esta funcion se encarga de que Player solo pueda llevar un ingrediente a la vez
        if self.Ingrediente is None:
            #Si no tiene ninguno, agarrara uno
            self.Ingrediente= ingrediente
            return True
        else: 
            #Si ya posee uno, no podra agarrar otro
            print("Solo se puede cargar un ingrediente a la vez")
            return False
    
    def soltarIngrediente (self):
        #Esta funcion se encarga de que Player pueda soltar el ingrediente
        self.Ingrediente=None

    def mover(self, event):
        #Esta funcion permite que el player se pueda mover
        tecla = event.keysym.lower()
        if tecla == "w":
            self.y -= 5
            self.face = "arriba"
        elif tecla == "s":
            self.y += 5
            self.face = "abajo"
        elif tecla == "a":
            self.x -= 5
            self.face = "izquierda"
        elif tecla == "d":
            self.x += 5
            self.face = "derecha"
        else:
            return

"""--------------------------------------------------------------------------------------------------------"""

class Plato():
    """Esta funcion no viene en el documento, pero la veo necesaria ya que hay que construir un objeto donde se lleven 
    los ingredientes de la receta y que sea comparado en la estacion de entregar recetas, posee solamente un 
    atributo que es una lista de Ingredientes"""
    def __init__(self):
        self.ingredientesDelPlato = [] #Lista de objetos Ingrediente

    def agregarIngrediente(self, ingrediente):
        #Se agregara solo si el ingrediente esta preparado
        if ingrediente.estado==True:
            self.ingredientesDelPlato.append(ingrediente)
            return True 
        else:
            print("El ingrediente no esta preparado")
            return False

    def limpiarPlato(self):
        #Este metodo quita todos los ingredientes
        self.ingredientesDelPlato=[]

"""--------------------------------------------------------------------------------------------------------"""

class Cocina():
    #Esta Clase es la encargada de los escenarios del juego, posee 4 atributos que son los mencionados en el constructor 
    def __init__(self,tiempo, escenario, players, ordenes):
        self.tiempo = tiempo #int
        self.escenario = escenario #Int: 1 or 2 or 3
        self.players = players #List de objetos Player
        self.ordenes = ordenes #List de objetos Receta

    def generaReceta(self):
        #Se escoge una receta ya predeterminada al azar con la biblioteca random dependiendo del escenario en juego
        if len(self.ordenes) >= 4:  # Noo generara más recetas si ya hay 4
            return None
        elif self.escenario == 1:
            recetaEscogida = random.choice(RecetasRestauranteVolador)
        elif self.escenario == 2:
            recetaEscogida = random.choice(RecetasRestauranteFrances)   
        elif self.escenario == 3:
            recetaEscogida = random.choice(RecetasRestauranteEnLaCosta)

        self.ordenes.append(recetaEscogida)
        return recetaEscogida
    
    def getTiempo(self):
        return self.tiempo 
    def setTiempo(self, time):
        self.tiempo=time

"""--------------------------------------------------------------------------------------------------------"""

class Estacion ():
    #Esta clase se encarga de preparar los objetos ingredientes y de cambiar sus estados dependiento el nombre de la estacion
    def __init__ (self, nombre, Ingrediente=None, aceptados=None, x=0, y=0):
        self.nombre = nombre #string
        self.Ingrediente = Ingrediente #Objeto Ingrediente
        self.aceptados = aceptados #List de objetos Receta
        self.x=x
        self.y=y

    def setX(self,x):
        self.x=x #Agrega un nuevo valor a x
    def setY(self,y):
        self.y=y #Agrega un nuevo valor a y

    def procesarIngredientes(self):
        if self.nombre == "estCocina":
            #Aqui se preparan los de tipo Proteina
            if isinstance(self.Ingrediente, Panes_Y_Bases):
                self.Ingrediente.cocinar()
                self.Ingrediente.estado = True
                print ("Cocinado")
            else: 
                print ("Este ingrediente no es un pan o base")
        elif self.nombre== "tablaDePicar":
            #Aqui los de tipo Vegetales_Y_Frutas
            if isinstance(self.Ingrediente, Vegetales_Y_Frutas):     
                self.Ingrediente.cortar()
                self.Ingrediente.estado = True
                print("Cortado!")
            else:print("Esto no es un vegetal o fruta!")
        elif self.nombre== "freidora":
            #Aqui los de tipo Panes_Y_Bases
            if isinstance(self.Ingrediente, Proteinas):              
                self.Ingrediente.freir()
                self.Ingrediente.estado = True
                print("Freido!")
            else:
                print("Este ingrediente no es una proteina")

    def dispensador(self):
        """Esta funcion se encarga de que el player pueda agarrar un ingrediente de la estacion en estado False"""
        return self.Ingrediente.__class__(self.Ingrediente.nombre)

    def mostradorDeComidas(self):
        """Este metodo es donde se entregan los ingredientes, si coinciden y
           cumplen con los requerimientos, se entregan los puntos ya establecidos de dicha recetata 
           terminada"""
        if self.nombre == "mostrador":
        # Si no tiene lista de ingredientes entregados, la crea
            if not hasattr(self, 'ingredientesEntregados'):
                self.ingredientesEntregados = []
        
        # Agrega el ingrediente actual a la lista
        self.ingredientesEntregados.append(self.Ingrediente)
        
        # Revisa si alguna receta ya está completa
        for receta in self.aceptados:
            if receta.comparaReceta(self.ingredientesEntregados):
                self.ingredientesEntregados = []  # limpia por asi decirlo el plato para la siguiente receta
                self.aceptados.remove(receta) #Esto lo elimina de la recetas activas
                return receta.puntosReceta
        
        return 0  # aún no está completa ninguna receta


"""----------------------------------------------------------------------------------------"""

#Aqui estan las recetas predeterminadas para cada escenario, cada una con su lista de ingredientes, puntos y tiempo maximo
RecetasRestauranteVolador = [
    Receta([Proteinas("pollo"), Panes_Y_Bases("papa")], 20, 40),
    Receta([Proteinas("pollo"), Vegetales_Y_Frutas("tomate"), Panes_Y_Bases("papa")], 30, 55),
    Receta([Vegetales_Y_Frutas("frijoles"), Panes_Y_Bases("arroz")], 20, 40),
    Receta([Proteinas("pollo"), Vegetales_Y_Frutas("platano"), Panes_Y_Bases("arroz")], 30, 55),
]      
RecetasRestauranteFrances = [
    Receta([Proteinas("cerdo"), Panes_Y_Bases("fideos")], 20, 40),
    Receta([Proteinas("cerdo"), Vegetales_Y_Frutas("zanahoria")], 20, 40),
    Receta([Panes_Y_Bases("fideos"), Vegetales_Y_Frutas("brocoli"), Proteinas("cerdo")], 30, 55),
    Receta([Panes_Y_Bases("papa"), Vegetales_Y_Frutas("zanahoria"), Vegetales_Y_Frutas("brocoli")], 30, 55),
]
RecetasRestauranteEnLaCosta = [
    Receta([Proteinas("salmon"), Panes_Y_Bases("baguette")], 20, 40),
    Receta([Proteinas("salmon"), Vegetales_Y_Frutas("espinaca"), Panes_Y_Bases("baguette")], 30, 55),
    Receta([Panes_Y_Bases("tortilla"), Vegetales_Y_Frutas("champinones")], 20, 40),
    Receta([Proteinas("salmon"), Panes_Y_Bases("tortilla"), Vegetales_Y_Frutas("espinaca")], 30, 55),
]
"""--------------------------------------------------------------------------------------------------------"""

#Dispensadores del nivel 1
Dis_Pollo=Estacion("Dis_Pollo", Proteinas("pollo"))
Dis_Arroz=Estacion("Dis_Arroz", Panes_Y_Bases("arroz"))
Dis_Tomate=Estacion("Dis_Tomate", Vegetales_Y_Frutas("tomate"))
Dis_Frijoles=Estacion("Dis_Frijoles", Vegetales_Y_Frutas("frijoles"))
Dis_Platano=Estacion("Dis_Platano", Vegetales_Y_Frutas("platano"))
Dis_Papa=Estacion("Dis_Papa", Panes_Y_Bases("papa"))
#Dispensadores del nivel 2

Dis_Cerdo=Estacion("Dis_Cerdo", Proteinas("cerdo"))
Dis_Fideos=Estacion("Dis_Fideos", Panes_Y_Bases("fideos"))
Dis_Zanahoria=Estacion("Dis_Zanahoria", Vegetales_Y_Frutas("zanahoria"))
Dis_Brocoli=Estacion("Dis_Brocoli", Vegetales_Y_Frutas("brocoli"))
Dis_Arros2=Estacion("Dis_Arroz2", Panes_Y_Bases("arroz"))
Dis_Papa=Estacion("Dis_Papa", Panes_Y_Bases("papa"))
#Dispensadores del nivel 3
Dis_Salmon=Estacion("Dis_Salmon", Proteinas("salmon"))
Dis_Baguette=Estacion("Dis_Baguette", Panes_Y_Bases("baguette"))
Dis_Espinaca=Estacion("Dis_Espinaca", Vegetales_Y_Frutas("espinaca"))
Dis_Tortilla=Estacion("Dis_Tortilla", Panes_Y_Bases("tortilla"))
Dis_Champinones=Estacion("Dis_Champinon", Vegetales_Y_Frutas("champinon"))

"""--------------------------------------------------------------------------------------------------------"""
#Los objetos que modifican el estado de los Ingredientes
freidora=Estacion("freidora")
tablaDePicar=Estacion("tablaDePicar")
estCocina=Estacion("estCocina")
#Este objetp mostrador, se encarga de recibir las recetas terminadas 
mostrador=Estacion("mostrador")

"""--------------------------------------------------------------------------------------------------------"""

#Estos son los espacios en los que se pueden ir construyendo las recetas
plato1=Plato()
plato2=Plato()
plato3=Plato()  

"""--------------------------------------------------------------------------------------------------------"""