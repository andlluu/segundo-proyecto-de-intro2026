from tkinter import *
import os
from Clases_y_objetos import *

"""----------------------------------------------------------------------------"""

def cargarImagen(nombre):
    #Esta funcion se encargara de crear una ruta para la imagen de fonfo para la pantalla de inicio
    ruta=os.path.join("imagenes",  nombre)
    imagen=PhotoImage(file=ruta)
    return imagen

def cargarImagenMaterial(nombre):
    #Esta funcion se encargara de crear una ruta para las imagenes de Materiales
    ruta=os.path.join("imagenes", "Material",  nombre)
    imagen=PhotoImage(file=ruta)
    return imagen

"""--------------------------------------------------------------------------------"""

def Cocina3Costa(): #Este es el tercer escenario creado, se llama restaurante en la costa
    FrameCocina3=Frame()
    FrameCocina3.pack(fill=BOTH, expand=TRUE)
    FotoFondoCocina3=cargarImagen("CocinaIsla.png")
    FotoFondoCocina3=FotoFondoCocina3.zoom(1,1)
    LabelFondoCocina3=Label(FrameCocina3, image=FotoFondoCocina3)
    LabelFondoCocina3.place(relx=0.5, rely=0.5, anchor="center")
    LabelFondoCocina3.lower()
    LabelFondoCocina3.image=FotoFondoCocina3

    CocinaCosta = Cocina(tiempo=150, escenario=3, players=[], ordenes=[])

    def pantallaTiempoAcabado():
        def FuncionBotonRegresar(): #Funcion que regresa al frame de elegir mapa y suma los puntos a los puntosAcumulados
            import Interfaz_grafica_inicio
            Interfaz_grafica_inicio.PuntosAcumulados += Jugador1.puntos  # Modifica la variable la original 
            Jugador1.puntos = 0 #reinicia los puntos para que se inicie una partida sin puntos
            from InterfazGraficaSelectMap import pantallaDeSeleccionMap
            FrameCocina3.pack_forget()
            ventanaMap3.destroy()
            pantallaDeSeleccionMap()

        #Aqui se va a crear la ventana para cuando se acaba el tiempo en el mapa 3
        ventanaMap3=Tk()
        ventanaMap3.title("El tiempo se ha acabado!")
        ventanaMap3.geometry("200x350")
        ventanaMap3.config(bg="light green")
        ventanaMap3.resizable(width=NO, height=NO)
        MensajeTiempoAcabado=Label(ventanaMap3, text=(f"El tiempo de la partina\nha finalizado!\nPuntos Obtenidos: {Jugador1.puntos}"))
        MensajeTiempoAcabado.place(relx=0.5, rely=0.4, anchor="center")
        MensajeTiempoAcabado.config(bg="light green")
        botonRegresarAlMapa=Button(ventanaMap3, text=("Regresar al mapa"), command=FuncionBotonRegresar)
        botonRegresarAlMapa.place(relx=0.5, rely=0.8, anchor="center")

    """--------------------------------------------------------------------------------"""

    def ContarTiempo(): #Un contador que va disminuyendo el tiempo de partida
        tiempoActual=CocinaCosta.getTiempo() #Se llama al metodo de obtener el tiempo de la cocina 
        tiempoActual=tiempoActual-1 #Resta uno al tiempo
        CocinaCosta.setTiempo(tiempoActual) #Y  se le agrega el resultado anterior al tiempo de la cocina
        LabelTiempoRestantePantalla.config(text=f"Tiempo Restante: {tiempoActual}") #Esto actualiza el tiempo en pantalla
        if tiempoActual > 0:
            FrameCocina3.after(1000, ContarTiempo)
        else:
            pantallaTiempoAcabado()

    """-----------------------------------------------------------------------------------"""
    
    #Ahora se creara un frame que estara en la panatalla en odne veremos las recetas activas
    LabelRecetas=Label(FrameCocina3, text="", bg="white")
    LabelRecetas.place(x=350, y=0)
    def mostrarRecetas():
        #Aqui muestra el nombre de los ingredinetes a ocupar recorriendo con un for la lista de  los ingredientes del objeto Cocina
        texto="Receta por Hacer: "
        for orden in CocinaCosta.ordenes:
            nombre=[ing.nombre for ing in orden.listaIngredientes]
            texto+= " | " + ", ".join(nombre)
        LabelRecetas.config(text=texto)

    def generarRecetaAleatoria():
        #Aqui se generan las recetas de forma aleatoria
        CocinaCosta.generaReceta()
        mostrarRecetas()
        if CocinaCosta.getTiempo() > 0:
            FrameCocina3.after(15000, generarRecetaAleatoria)
    generarRecetaAleatoria()

    """--------------------------------------------------------------------------------"""

    #Esto es un Label que mostrara el tiempo restante en panatalla
    LabelTiempoRestantePantalla=Label(FrameCocina3, text="", bg="grey")
    LabelTiempoRestantePantalla.place(x=1050, y=0)
    LabelTiempoRestantePantalla.config(text=f"Tiempo Restante: {CocinaCosta.getTiempo()}")

    #Este es para mostrar los puntos que se van obteniendo durante la partida!
    LabelMostrarPuntos = Label(FrameCocina3, text="Puntos: 0", bg="grey")
    LabelMostrarPuntos.place(x=1050, y=20)
    def actualizarPuntos(): 
        LabelMostrarPuntos.config(text=f"Puntos: {Jugador1.puntos}")

    """-----------------------------------------------------------------------------------"""

    """Objetos personajes"""
    from Interfaz_grafica_inicio import Jugador1 
    from Interfaz_grafica_inicio import Jugador2

    #Posicion e imagenes del jugador 1
    imgJugador1 = cargarImagen("personaje1abajo.gif")
    Jugador1.setX(600) 
    Jugador1.setY(350)
    Jugador1Label= Label(FrameCocina3, image=imgJugador1)
    Jugador1Label.place(x=Jugador1.x, y=Jugador1.y)
    Jugador1Label.image=imgJugador1
    Jugador1Label.lift()
    #Posicion e imagenes del jugador 2
    imgJugador2 = cargarImagen("personaje2abajo.gif")
    Jugador2.setX(700)
    Jugador2.setY(350)
    Jugador2Label = Label(FrameCocina3, image=imgJugador2)
    Jugador2Label.place(x=Jugador2.x, y=Jugador2.y)
    Jugador2Label.image = imgJugador2
    Jugador2Label.lift()

    jugadorActivo=Jugador1#Se crea una variable para que sea el jugador activo

    #Esto se encargara de poder observar que se posee en la mano:
    FrameEnMano=Frame(FrameCocina3, bg="brown", width=80, height=80) #Se crea el frame en donde se vera el objeto sostenido
    FrameEnMano.place(x=0,y=0)
    FrameEnMano.pack_propagate(False) 
    labelEnMano=Label(FrameEnMano, bg="brown") #Se crea la etiqueta
    labelEnMano.place(x=0, y=0)
    labelEnMano.pack(expand=True)

    def actualizarMano(jugador): 
        #Luego se crea la funcion que actualiza la imagen del objeto sostenido 
        if jugador.Ingrediente is not None: #Si tiene algo, pasa:
            estado = "True" if jugador.Ingrediente.estado else "False" #Verifica el estado del objeto
            nuevaImg = cargarImagenMaterial(f"{jugador.Ingrediente.nombre}{estado}.png") #Lo compara con las imagenes y escoge la indicada
            labelEnMano.config(image=nuevaImg)
            labelEnMano.image = nuevaImg
            FrameEnMano.image=nuevaImg
        else: #Si no, no se pone ninguna imagen
            labelEnMano.config(image="")
            labelEnMano.image = None

    def interactuar(jugador):
        print(f"Jugador en: x={jugador.x}, y={jugador.y}, mirando: {jugador.face}")
        #Esta funcion se encarga de interactuar con las estaciones que se encuentran en el nivel
        todasLasEstaciones=[ #Primero se crea una lista que contenga las estaciones del nivel
            freidora, tablaDePicar, estCocina, mostrador,
            Dis_Salmon, Dis_Baguette, Dis_Espinaca, Dis_Tortilla, Dis_Champinones
        ]

        for estacion in todasLasEstaciones:
            print(f"Revisando {estacion.nombre} - distancia x:{abs(jugador.x - estacion.x)} y:{abs(jugador.y - estacion.y)}")
    
            # Verifica cercanía según la dirección que mira el jugador
            cercano = False
            if jugador.face == "izquierda" and estacion.x < jugador.x:
                if abs(jugador.x - estacion.x) < 100 and abs(jugador.y - estacion.y) < 80:
                    cercano = True
            elif jugador.face == "derecha" and estacion.x > jugador.x :
                if abs(jugador.x - estacion.x) < 100 and abs(jugador.y - estacion.y) < 80:
                    cercano = True
            elif jugador.face == "arriba" and estacion.y < jugador.y:
                if abs(jugador.y - estacion.y) < 100 and abs(jugador.x - estacion.x) < 80:
                    cercano = True
            elif jugador.face == "abajo" and estacion.y > jugador.y:
                if abs(jugador.y - estacion.y) < 100 and abs(jugador.x - estacion.x) < 80:
                    cercano = True

            if not cercano:
                continue  # Si no está cerca ni mirando, sigue con la siguiente estación

            print(f"Cerca de {estacion.nombre}")

            if "Dis_" in estacion.nombre:
                #Si la estacion en su nombre posee Dis_ es pq es un dispensador, por ende otorga un objeto
                ingredientes = estacion.dispensador()
                jugador.UnIngrediente(ingredientes)

            elif estacion.nombre in ["estCocina", "tablaDePicar", "freidora"]:
                #De lo contrario si se llama como uno de los tres en la lista, procesa el ingrediente que se tiene en la mano
                if jugador.Ingrediente is not None:
                    estacion.Ingrediente = jugador.Ingrediente
                    estacion.procesarIngredientes()
                    jugador.soltarIngrediente()
                    print("Ingrediente dejado en estacion!")
                elif estacion.Ingrediente is not None and estacion.Ingrediente.estado == True:
                    #Si tiene las manos vacías y la estación tiene algo ya listo, lo recoge
                    jugador.UnIngrediente(estacion.Ingrediente)
                    estacion.Ingrediente = None
                    print("Ingrediente recogido!")
                else:
                    return 
                print ("No hay nada aquí")

            elif estacion.nombre == "mostrador":
                #Si se llama mostrador, se agrega el objeto en la mano y se compara con una de las listas activas en el momento
                if jugador.Ingrediente is not None:
                    estacion.Ingrediente = jugador.Ingrediente
                    estacion.aceptados = CocinaCosta.ordenes  # usa las ordenes activas
                    puntos = estacion.mostradorDeComidas()
                    Jugador1.puntos += puntos
                    jugador.soltarIngrediente()
                    mostrarRecetas()
                    actualizarPuntos()
            actualizarMano(jugador)
            break

    def moverJugador(event): #Esta funcion se encarga de mover al jugador por el mapa
        nonlocal jugadorActivo
        #Estos condicionales determinan cual jugador se va a usar dependiendo si se clickea la tecla q
        tecla=event.keysym.lower()
        if tecla=="q": #Cambie de personaje
            jugadorActivo=Jugador2 if jugadorActivo==Jugador1 else Jugador1
            return
        
        elif tecla=="r": #suelta el ingrediente
            jugadorActivo.soltarIngrediente()
            actualizarMano(jugadorActivo)
            return

        elif tecla=="e": #Con la letra e, se interactua en la cocina, llamando a la funcion interactuar
            interactuar(jugadorActivo)
            return 

        jugadorActivo.mover(event)

        if jugadorActivo == Jugador1: #Si el persoanje activo es el jugador 1, se utilizan los siguientes comandos
            nuevaImagen = cargarImagen(f"personaje1{Jugador1.face}.gif")
            Jugador1Label.config(image=nuevaImagen)
            Jugador1Label.image = nuevaImagen
            Jugador1Label.place(x=Jugador1.x, y=Jugador1.y)
        else: #De lo contrario, si es el 2, se utilizan los comandos siguientes
            nuevaImagen = cargarImagen(f"personaje2{Jugador2.face}.gif")
            Jugador2Label.config(image=nuevaImagen)
            Jugador2Label.image = nuevaImagen
            Jugador2Label.place(x=Jugador2.x, y=Jugador2.y)
        
    FrameCocina3.bind("<Key>", moverJugador)
    FrameCocina3.focus_set()

    """-----------------------------------------------------------------------------------"""
    """En otras palabras, lo que se muestra de aqui en adelante son las interfaces graficas de los objetos"""
    
    """Objetos Estaciones:"""

    from Clases_y_objetos import freidora
    imgFreidora=cargarImagen("EstacionFreidora.png")
    imgFreidora=imgFreidora.subsample(8,8)
    freidoraLabel=Label(FrameCocina3, image=imgFreidora)
    freidoraLabel.place(x=675, y=170)
    freidora.setX(675)
    freidora.setY(170)
    freidoraLabel.image=imgFreidora

    from Clases_y_objetos import tablaDePicar
    imgTablaDePicar=cargarImagen("EstacionTablaDePicar.png")
    imgTablaDePicar=imgTablaDePicar.subsample(4,4)
    tablaDePicarLabel=Label(FrameCocina3, image=imgTablaDePicar)
    tablaDePicarLabel.place(x=135, y=285)
    tablaDePicar.setX(135)
    tablaDePicar.setY(285)
    tablaDePicarLabel.image=imgTablaDePicar

    from Clases_y_objetos import estCocina
    imgEstCocina=cargarImagen("EstacionCocina.png")
    imgEstCocina=imgEstCocina.subsample(2,2)
    estCocinaLabel=Label(FrameCocina3, image=imgEstCocina)
    estCocinaLabel.place(x=395,y=190)
    estCocina.setX(395)
    estCocina.setY(190)
    estCocinaLabel.image=imgEstCocina

    from Clases_y_objetos import mostrador, RecetasRestauranteEnLaCosta
    mostrador.aceptados = RecetasRestauranteEnLaCosta
    imgMostrador=cargarImagen("EstacionMostrador.png")
    imgMostrador=imgMostrador.subsample(3,3)
    mostradorLabel=Label(FrameCocina3, image=imgMostrador)
    mostradorLabel.place(x=1030,y=350)
    mostrador.setX(1030)
    mostrador.setY(350)
    mostradorLabel.image=imgMostrador

    """Estaciones para recoger ingredientes"""

    from Clases_y_objetos import Dis_Salmon
    imgDis_Salmon = cargarImagenMaterial("salmonFalse.png")
    imgDis_Salmon = imgDis_Salmon.subsample(3,3)
    Dis_SalmonLabel = Label(FrameCocina3, image=imgDis_Salmon)
    Dis_SalmonLabel.place(x=100, y=550)
    Dis_Salmon.setX(100)
    Dis_Salmon.setY(550)
    Dis_SalmonLabel.image = imgDis_Salmon
    prepararSalmon = Label(FrameCocina3, text="freir")
    prepararSalmon.place(x=100, y=650)

    from Clases_y_objetos import Dis_Baguette
    imgDis_Baguette = cargarImagenMaterial("baguetteFalse.png")
    imgDis_Baguette = imgDis_Baguette.subsample(3,3)
    Dis_BaguetteLabel = Label(FrameCocina3, image=imgDis_Baguette)
    Dis_BaguetteLabel.place(x=200, y=550)
    Dis_Baguette.setX(200)
    Dis_Baguette.setY(550)
    Dis_BaguetteLabel.image = imgDis_Baguette
    prepararBaguette = Label(FrameCocina3, text="cocinar")
    prepararBaguette.place(x=200, y=650)

    from Clases_y_objetos import Dis_Espinaca
    imgDis_Espinaca = cargarImagenMaterial("espinacaFalse.png")
    imgDis_Espinaca = imgDis_Espinaca.subsample(9,9)
    Dis_EspinacaLabel = Label(FrameCocina3, image=imgDis_Espinaca)
    Dis_EspinacaLabel.place(x=850, y=550)
    Dis_Espinaca.setX(850)
    Dis_Espinaca.setY(550)
    Dis_EspinacaLabel.image = imgDis_Espinaca
    prepararEspinaca = Label(FrameCocina3, text="cortar")
    prepararEspinaca.place(x=850, y=650)


    from Clases_y_objetos import Dis_Tortilla
    imgDis_Tortilla = cargarImagenMaterial("tortillaFalse.png")
    imgDis_Tortilla = imgDis_Tortilla.subsample(3,3)
    Dis_TortillaLabel = Label(FrameCocina3, image=imgDis_Tortilla)
    Dis_TortillaLabel.place(x=400, y=550)
    Dis_Tortilla.setX(400)
    Dis_Tortilla.setY(550)
    Dis_TortillaLabel.image = imgDis_Tortilla
    prepararTortilla = Label(FrameCocina3, text="cocinar")
    prepararTortilla.place(x=400, y=650)

    from Clases_y_objetos import Dis_Champinones
    imgDis_Champinones = cargarImagenMaterial("champinonFalse.png")
    imgDis_Champinones = imgDis_Champinones.subsample(4,4)
    Dis_ChampinonesLabel = Label(FrameCocina3, image=imgDis_Champinones)
    Dis_ChampinonesLabel.place(x=750, y=550)
    Dis_Champinones.setX(750)
    Dis_Champinones.setY(550)
    Dis_ChampinonesLabel.image = imgDis_Champinones
    prepararChampinones = Label(FrameCocina3, text="cortar")
    prepararChampinones.place(x=750, y=650)

    """-------------------------------------------------------------------------------------"""
    
    ContarTiempo()