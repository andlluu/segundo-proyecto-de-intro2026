from tkinter import *
import os
from Clases_y_objetos import * 
from tkinter import messagebox
from InterfazGraficaSelectMap import *

Jugador1=Player("Jugador1") #Se crea primero el objeto Jugador1
Jugador2=Player("Jugador2") #Luego, el segundo objeto Jugador2
PuntosAcumulados=0
"""-------------------------------------------------------------------------------------"""

def cargarImagen(nombre):
    #Esta funcion se encargara de crear una ruta para las imagenes 
    ruta=os.path.join("imagenes",  nombre)
    imagen=PhotoImage(file=ruta)
    return imagen

"""---------------------------------------------------------------------------------"""

def pantallaDeInicio():
    #Aqui se crea la pantalla inicial con la biblioteca Tkinter
    ventana=Tk() #Se nombra la funcion Tk() como panatalla
    ventana.title("Crazy Snack Rush") #Se pone un titulo a la pantalla
    ventana.geometry("1200x700") #Aqui se elije el tamaño de dicha panatalla
    ventana.resizable(width=NO, height=NO) #Esto evita que el usuario pueda hacer mas grande o mas pequeña la pantalla
    fotoFondo=cargarImagen("fondo.gif") #Aqui se esta usando la funcion anterior
    labelFondo=Label(ventana, image=fotoFondo) #Aqui pone la imagen como una especie de texto 
    labelFondo.place(x=0, y=0) #Se coloca en el centro
    labelFondo.image=fotoFondo
    
    """---------------------------------------------------------------------------------"""
    #Lo siguiente son los botones y sus funciones:
    def botonInfor1():
        #Esta funcion se encaraga de decir informacion relevante del juego
        FrameInformacion=Frame(ventana, width=300, height=300)
        FrameInformacion.place(relx=0.5, rely=0.4, anchor="center")
        FrameInformacion.pack_propagate(False) 
        FrameInformacion.config(bg="#4F98EB")
        FrameInformacion.config(bd=4, relief="ridge")
        LabelInforma=Label(FrameInformacion, text="Creadores:\nAnderson Lu Lu\nSebastian Solano Porras\n\nControles para Jugar:\nCaminar adelate: w\nCaminar atras: s\nCaminar izquierda: a\nCaminar Derecha: d\nInteractuar con objetos: e\nQuitar objeto de mano: r\n Cambiar de persoanje: q")
        LabelInforma.place(relx=0.5, rely=0.4, anchor="center")
        LabelInforma.config(bg="#4F98EB") #No tenia idea que se podia elegir un color así, pero es mas facil
        LabelInforma.config(bd=4, relief="ridge")
        def  QuitarInfo(): #Esta funcion hara que cuando presionemos el boton de quitar, se destruya este frame
            FrameInformacion.destroy()
        BotonQuitar=Button(FrameInformacion, text="Cerrar Informacion", command=QuitarInfo)
        BotonQuitar.place(relx=0.5, rely=0.9, anchor="center") 
    botonInfo = Button(ventana, text="Informacion", command=botonInfor1) #Boton creado desde Tkinter
    botonInfo.place(x=1100, y=25) #Posicion del boton

    def botonPlays(): #Esta funcion hace que pasemos a la siguiente partida al dar click en el boton de PLAY
        nombre=solicitarNombre.get() #Al objeto Jugador1 y Jugador2 se les otorga el nombre escrito por el usuario
        if nombre=="": #Si el nombre es vacio, da ERROR
            messagebox.showwarning("ERROR", "Por favor escriba su nombre")
        else: #De lo contrario, se ejecuta la funcion pantallaDeSeleccionPersonaje que esta en otro documento para mas orden
            Jugador1.setNombre(nombre) 
            Jugador2.setNombre(nombre)
            pantallaDeSeleccionMap()
    botonPlay = Button(ventana, text="PLAY", command=botonPlays) #Se crea el boton PLAY
    botonPlay.place(x=625, y=600) #Se posiciona

    #Con esto, podremos digitar el nombre al inicio antes de iniciar 
    escribaSuNombre=Label(ventana, text="Ingrese su nombre:")
    escribaSuNombre.place(x=500, y=500)
    solicitarNombre=Entry(ventana)
    solicitarNombre.place(x=607, y=501)
    solicitarNombre.bind("<Return>", botonPlay)


    ventana.mainloop() #Esto es escensial, evita que la pantalla se cierre apenas se inicia el programa 

if __name__ =="__main__":
    pantallaDeInicio()
