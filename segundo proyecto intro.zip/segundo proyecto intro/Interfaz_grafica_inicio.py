from tkinter import *
import os
from Clases_y_objetos import * 
from tkinter import messagebox
from InterfazGraficaSelectMap import *

"""-------------------------------------------------------------------------------------"""
def cargarImagen(nombre):
    #Esta funcion se encargara de crear una ruta para la imagen de fonfo para la pantalla de inicio
    ruta=os.path.join("imagenes",  nombre)
    imagen=PhotoImage(file=ruta)
    return imagen

"""---------------------------------------------------------------------------------"""

#Aqui se crea la pantalla inicial con la biblioteca Tkinter
ventana=Tk() #Se nombra la funcion Tk() como panatalla
ventana.title("Crazy Snack Rush") #Se pone un titulo a la pantalla
ventana.geometry("1200x700") #Aqui se elije el tamaño de dicha panatalla
ventana.resizable(width=NO, height=NO) #Esto evita que el usuario pueda hacer mas grande o mas pequeña la pantalla
fotoFondo=cargarImagen("fondo.gif") #Aqui se esta usando la funcion anterior
labelFondo=Label(ventana, image=fotoFondo) #Aqui pone la imagen como una especie de texto 
labelFondo.place(x=0, y=0) #Se coloca en el centro
labelFondo.image=fotoFondo

"""---------------------------------------------------------------------------------"""
#Lo siguiente son los botones y sus funciones:

def botonInfor(): #Esta es la funcion se encarga de brindar informacion al presionar el boton "botonInfo"
    ventana=Tk() #Crea una nueva ventana
    ventana.title("Informacion del juego") #Su titulito
    ventana.geometry("200x100") #tamaño
    ventana.config(bg="green") #color de fondo
    ventana.resizable(width=NO, height=NO) #impide que se haga mas grande o pequeña
    labelInformacion=Label(ventana, text=("Creadores:\nAnderson Lu Lu\nSebastian Solano Porras")) #La etiqueta con la informacion necesaria
    labelInformacion.place(x=35,y=15) #Posicion de la etiqueta 
    labelInformacion.config(bg=("green")) #Color del fondo de la etiqueta
botonInfo = Button(ventana, text="Informacion", command=botonInfor) #Boton creado desde Tkinter
botonInfo.place(x=1100, y=25) #Posicion del boton

def botonPlays(): #Esta funcion hace que pasemos a la siguiente partida al dar click en el boton de PLAY
    nombre=solicitarNombre.get() #Se crea la variable nombre que resibe el nombre de la Entrada
    if nombre=="": #Si el nombre es vacio, da ERROR
        messagebox.showwarning("ERROR", "Por favor escriba su nombre")
    else: #De lo contrario, se ejecuta la funcion pantallaDeSeleccionPersonaje que esta en otro documento para mas orden
        chef1=Player(nombre) #Crea un objeto player, importado del documento de las clases
        pantallaDeSeleccionMap()
botonPlay = Button(ventana, text="PLAY", command=botonPlays) #Se crea el boton PLAY
botonPlay.place(x=625, y=600) #Se posiciona

#Con esto, podremos digitar el nombre al inicio antes de iniciar 
escribaSuNombre=Label(ventana, text="Ingrese su nombre:")
escribaSuNombre.place(x=500, y=500)
solicitarNombre=Entry(ventana)
solicitarNombre.place(x=607, y=501)
solicitarNombre.bind("<Return>", botonPlay)


ventana.mainloop() #Esto es escensial, evita que la pantalla se cierre apenas se inicia el programa 

