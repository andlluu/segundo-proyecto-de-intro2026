from tkinter import *
import os
from Clases_y_objetos import *

"""------------------------------------------------------------------------------------------"""

def cargarImagen(nombre):
    #Esta funcion se encargara de crear una ruta para la imagen de fonfo para la pantalla de inicio
    ruta=os.path.join("imagenes",  nombre)
    imagen=PhotoImage(file=ruta)
    return imagen

"""------------------------------------------------------------------------------------------"""

def Cocina1Volador(): #Este es el primer escenario creado, sera el Restaurante Volador
    FrameCocina1=Frame()
    FrameCocina1.pack(fill=BOTH, expand=True)
    FotoFondoCocina1=cargarImagen("CocinaVoladora.png")
    FotoFondoCocina1=FotoFondoCocina1.zoom(1,1)
    LabelFondoCpcina1=Label(FrameCocina1, image=FotoFondoCocina1)
    LabelFondoCpcina1.place(relx=0.5, rely=0.5, anchor="center")
    LabelFondoCpcina1.lower()
    LabelFondoCpcina1.image=FotoFondoCocina1

    CocinaVolador = Cocina(tiempo=160, escenario=1, players=[], ordenes=[])
    
    def pantallaTiempoAcabado():
        def FuncionBotonRegresar():
            from InterfazGraficaSelectMap import pantallaDeSeleccionMap
            FrameCocina1.pack_forget()
            ventanaMap1.destroy()
            pantallaDeSeleccionMap()
        ventanaMap1=Tk()
        ventanaMap1.title("El tiempo se ha acabado!")
        ventanaMap1.geometry("200x350")
        ventanaMap1.config(bg="light green")
        ventanaMap1.resizable(width=NO, height=NO)
        MensajeTiempoAcabado=Label(ventanaMap1, text=("El tiempo de la partina\nha finalizado!\nPuntos Obtenidos:"))
        MensajeTiempoAcabado.place(relx=0.5, rely=0.4, anchor="center")
        MensajeTiempoAcabado.config(bg="light green")
        botonRegresarAlMapa=Button(ventanaMap1, text=("Regresar al mapa"), command=FuncionBotonRegresar)
        botonRegresarAlMapa.place(relx=0.5, rely=0.8, anchor="center")
        
    def ContarTiempo():
        tiempoActual=CocinaVolador.getTiempo()
        tiempoActual=tiempoActual-1
        CocinaVolador.setTiempo(tiempoActual)
        print("Tiempo actual:", tiempoActual)
        if tiempoActual > 0:
            FrameCocina1.after(1000, ContarTiempo)
        else:
            print ("si ejecuto")
            pantallaTiempoAcabado()
            
    ContarTiempo()