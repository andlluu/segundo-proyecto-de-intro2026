"""Aqui se guardaran las clases principales que pide el documento del proyecto,
ademas son las que estan en el principal diagrama UML. Entre cada clase se pondra una linea 
de guiones para que se vea mas ordenado el codigo"""

import random
import time

class Ingrediente():
    #Al ser que los ingredientes tienen el mismo formato, se crea una clase padre con el siguiente cosntructor
    def __init__(self, nombre, estado):
        self.nombre = nombre #string
        self.estado = estado #bool

"""--------------------------------------------------------------------------------------------------------"""

class Vegetales_Y_Frutas(Ingrediente):
    #Hija de la clase Ingredinete, posee un metodo que cambia el estado del ingrediente a True
    def __init__(self, nombre, estado=False):
        super().__init__(nombre, estado)

    def cortar(self):
        self.estado = True

"""--------------------------------------------------------------------------------------------------------"""

class Panes_Y_Bases(Ingrediente):
    #Hija de la clase Ingredinete, posee un metodo que cambia el estado del ingrediente a True
    def __init__(self, nombre, estado=False):
        super().__init__(nombre, estado)

    def preparar(self):
        self.estado = True

"""--------------------------------------------------------------------------------------------------------"""

class Proteinas(Ingrediente):
    #Hija de la clase Ingredinete, posee un metodo que cambia el estado del ingrediente a True
    def __init__(self, nombre, estado=False):
        super().__init__(nombre, estado)
        
    def cocinar(self):
        self.estado = True

"""--------------------------------------------------------------------------------------------------------"""

class Receta():
    """La clase receta se encanrga de guardar la lista de obtejos Ingrediente, los puntos que da la receta y el tiempo
    maximo para hacerla, ademas de tener un metodo para comparar la receta con una lista de ingredientes dada y 
    otro metodo para comparar el tiempo dado con el tiempo maximo de la receta"""
    def __init__(self, listaIngredientes, puntosReceta, maxTimeReceta):
        self.listaIngredientes = listaIngredientes #List de objetos Ingrediente
        self.puntosReceta = puntosReceta #int
        self.maxTimeReceta = maxTimeReceta #int

    def comparaReceta(self, listaIngredientes):
        #Compara si las recetas son iguales
        if len(listaIngredientes) != len(self.listaIngredientes): #Empieza comparando la cantidad de ingredientes 
            return False
        for i in range(len(listaIngredientes)):
            #Luego de comparar la cantaidad, comparara el nombre, es es diferente, retorna false
            if listaIngredientes[i].nombre != self.listaIngredientes[i].nombre:
                return False
            if listaIngredientes[i].estado != self.listaIngredientes[i].estado:
            #Lo mismo para el stado, si es diferente retorna False 
                return False
        return True #Si ninguno dio False y todo esta igual, retorna True 
        
        
    def TiempoLimite(self, tiempo):
        #Si el timepo dado es menor o igual al tiempo maximo de la receta, devuelve la mitad de los puntos de la receta, sino devuelve 0
        if tiempo <= self.maxTimeReceta:
            self.puntosReceta//=2 #aqui divide los puntos de la receta
            if self.puntosReceta <=0: #aqui establece un minimo de puntos que es cero
                self.puntosReceta =0
              

"""--------------------------------------------------------------------------------------------------------"""
class Player():
    #Esta clase posee tres atributos, el nombre del jugador, el ingrediente que lleva consigo y los puntos que posee, los cuales siempore inician en cero
    def __init__(self, nombre, Ingrediente=None):
        self.nombre = nombre #string
        self.puntos = 0 #int
        self.Ingrediente = Ingrediente #Un objeto Ingrediente

    def UnIngrediente(self, ingrediente):
        #Esta funcion se encarga de que Player solo pueda llevar un ingrediente a la vez
        if self.Ingrediente is None:
            #Si no tiene ninguno, agarrara uno
            self.Ingrediente= ingrediente
            return True
        else: 
            #Si ya posee uno, no podra agarrar otro
            print("Solo se puede cargar un ingrediente a la vez")
            return False
    
    def soltarIngrediente (self):
        #Esta funcion se encarga de que Player pueda soltar el ingrediente
        self.Ingrediente=None

    def mover(self, event):
        #Esta funcion permite que el player se peuda mover
        tecla = event.keysym.lower()
        if tecla == "w":
            self.y -= 10
            self.face = "arriba"
        elif tecla == "s":
            self.y += 10
            self.face = "abajo"
        elif tecla == "a":
            self.x -= 10
            self.face = "izquierda"
        elif tecla == "d":
            self.x += 10
            self.face = "derecha"
        else:
            return

"""--------------------------------------------------------------------------------------------------------"""
chef1=Player("chef1")
chef2=Player("chef2")
"""--------------------------------------------------------------------------------------------------------"""
class Plato():
    """Esta funcion no viene en el documento, pero la veo necesaria ya que hay que construir un objeto donde se lleven 
    los ingredientes de la receta y que sea comparado en la estacion de entregar recetas, posee solamente un 
    atributo que es una lista de Ingredientes"""
    def __init__(self):
        self.ingredientesDelPlato = [] #Lista de objetos Ingrediente

    def agregarIngrediente(self, ingrediente):
        #Se agregara solo si el ingrediente esta preparado
        if ingrediente.estado==True:
            self.ingredientesDelPlato.append(ingrediente)
            return True 
        else:
            print("El ingrediente no esta preparado")
            return False

    def limpiarPlato(self):
        #Este metodo quita todos los ingredientes
        self.ingredientesDelPlato=[]

"""--------------------------------------------------------------------------------------------------------"""

class Cocina():
    #Esta Clase es la encargada de los escenarios del juego, posee 4 atributos que son los mencionados en el constructor 
    def __init__(self,tiempo, escenario, players, ordenes):
        self.tiempo = tiempo #int
        self.escenario = escenario #Int: 1 or 2 or 3
        self.players = players #List de objetos Player
        self.ordenes = ordenes #List de objetos Receta

    def generaReceta(self):
        #Se escoge una receta ya predeterminada al azar con la biblioteca random dependiendo del escenario en juego
        if self.escenario == 1:
            recetaEscogida = random.choice(RecetasFaciles)
        elif self.escenario == 2:
            recetaEscogida = random.choice(RecetasMedianas)   
        elif self.escenario == 3:
            recetaEscogida = random.choice(RecetasDificiles)

        self.ordenes.append(recetaEscogida)
        return recetaEscogida

"""--------------------------------------------------------------------------------------------------------"""

class Estacion ():
    #Esta clase se encarga de preparar los objetos ingredientes y de cambiar sus estados dependiento el nombre de la estacion
    def __init__ (self, nombre, Ingrediente=None, aceptados=None):
        self.nombre = nombre #string
        self.Ingrediente = Ingrediente #Objeto Ingrediente
        self.aceptados = aceptados #List de objetos Receta

    def procesarIngredientes(self):
        if self.nombre == "cocina_freidora":
            #Aqui se preparan los de tipo Proteina
            if isinstance(self.Ingrediente, Proteinas):
                time.sleep(5)  
                self.Ingrediente.cocinar()
                self.Ingrediente.estado = True

        elif self.nombre== "tablaDePicar":
            #Aqui los de tipo Vegetales_Y_Frutas
            if isinstance(self.Ingrediente, Vegetales_Y_Frutas):
                time.sleep(3)  
                self.Ingrediente.cortar()
                self.Ingrediente.estado = True

        elif self.nombre== "horno":
            #Aqui los de tipo Panes_Y_Bases
            if isinstance(self.Ingrediente, Panes_Y_Bases):
                time.sleep(4)  
                self.Ingrediente.preparar()
                self.Ingrediente.estado = True

    def dispensador(self):
        """Esta funcion se encarga de que el player pueda agarrar un ingrediente de la estacion"""
        return self.Ingrediente

    def mostradorDeComidas(self):
        """Este metodo es donde se entregan las recetas ya terminadas, si coinciden y
           cumplen con los requerimientos, se entregan los puntos ya establecidos"""
        if self.nombre== "mostrador":
            for receta in self.aceptados:
                if receta.comparaReceta(Plato.ingredientesDelPlato):
                    return receta.puntosReceta
            print("La receta no cumple con lo pedido")
            return 0


"""----------------------------------------------------------------------------------------"""

#Aqui estan las recetas predeterminadas para cada escenario, cada una con su lista de ingredientes, puntos y tiempo maximo
RecetasFaciles = [
    Receta([Proteinas("pollo"), Panes_Y_Bases("arroz")], 20, 40),
    Receta([Proteinas("pollo"), Vegetales_Y_Frutas("tomate"), Panes_Y_Bases("arroz")], 30, 55),
    Receta([Vegetales_Y_Frutas("frijoles"), Panes_Y_Bases("arroz")], 20, 40),
    Receta([Proteinas("pollo"), Vegetales_Y_Frutas("platano"), Panes_Y_Bases("arroz")], 30, 55),
]      
RecetasMedianas = [
    Receta([Proteinas("cerdo"), Panes_Y_Bases("fideos")], 20, 40),
    Receta([Proteinas("cerdo"), Vegetales_Y_Frutas("zanahoria")], 20, 40),
    Receta([Panes_Y_Bases("fideos"), Vegetales_Y_Frutas("brocoli"), Proteinas("cerdo")], 30, 55),
    Receta([Panes_Y_Bases("arroz"), Vegetales_Y_Frutas("zanahoria"), Vegetales_Y_Frutas("brocoli")], 30, 55),
]
RecetasDificiles = [
    Receta([Proteinas("salmon"), Panes_Y_Bases("baguette")], 20, 40),
    Receta([Proteinas("salmon"), Vegetales_Y_Frutas("espinaca"), Panes_Y_Bases("baguette")], 30, 55),
    Receta([Panes_Y_Bases("crepa"), Vegetales_Y_Frutas("champiñones")], 20, 40),
    Receta([Proteinas("salmon"), Panes_Y_Bases("crepa"), Vegetales_Y_Frutas("espinaca")], 30, 55),
]
"""--------------------------------------------------------------------------------------------------------"""

#Dispensadores del nivel 1
Dis_Pollo=Estacion("Dis_Pollo", Proteinas("pollo"))
Dis_Arroz=Estacion("Dis_Arroz", Panes_Y_Bases("arroz"))
Dis_Tomate=Estacion("Dis_Tomate", Vegetales_Y_Frutas("tomate"))
Dis_Frijoles=Estacion("Dis_Frijoles", Vegetales_Y_Frutas("frijoles"))
Dis_Platano=Estacion("Dis_Platano", Vegetales_Y_Frutas("platano"))

#Dispensadores del nivel 2

Dis_Cerdo=Estacion("Dis_Cerdo", Proteinas("cerdo"))
Dis_Fideos=Estacion("Dis_Fideos", Panes_Y_Bases("fideos"))
Dis_Zanahoria=Estacion("Dis_Zanahoria", Vegetales_Y_Frutas("zanahoria"))
Dis_Brocoli=Estacion("Dis_Brocoli", Vegetales_Y_Frutas("brocoli"))
Dis_Arros2=Estacion("Dis_Arroz2", Panes_Y_Bases("arroz"))

#Dispensadores del nivel 3
Dis_Salmon=Estacion("Dis_Salmon", Proteinas("salmon"))
Dis_Baguette=Estacion("Dis_Baguette", Panes_Y_Bases("baguette"))
Dis_Espinaca=Estacion("Dis_Espinaca", Vegetales_Y_Frutas("espinaca"))
Dis_Crepas=Estacion("Dis_Crepas", Panes_Y_Bases("crepa"))
Dis_Champiñones=Estacion("Dis_Champiñones", Vegetales_Y_Frutas("champiñones"))

"""--------------------------------------------------------------------------------------------------------"""
#Los objetos que modifican el estado de los Ingredientes
cocina_freidora=Estacion("freidora")
tablaDePicar=Estacion("tablaDePicar")
horno=Estacion("horno")
#Este objetp mostrador, se encarga de recibir las recetas terminadas 
mostrador=Estacion("mostrador")

"""--------------------------------------------------------------------------------------------------------"""

#Estos son los espacios en los que se pueden ir construyendo las recetas
plato1=Plato()
plato2=Plato()
plato3=Plato()  

"""--------------------------------------------------------------------------------------------------------"""