from tkinter import *
import os
from Clases_y_objetos import *

"""------------------------------------------------------------------------------------------"""

def cargarImagen(nombre):
    #Esta funcion se encargara de crear una ruta para la imagen de fonfo para la pantalla de inicio
    ruta=os.path.join("imagenes",  nombre)
    imagen=PhotoImage(file=ruta)
    return imagen

def cargarImagenMaterial(nombre):
    #Esta funcion se encargara de crear una ruta para las imagenes de Materiales
    ruta=os.path.join("imagenes", "Material",  nombre)
    imagen=PhotoImage(file=ruta)
    return imagen

"""------------------------------------------------------------------------------------------"""

def Cocina1Volador(): #Este es el primer escenario creado, sera el Restaurante Volador
    FrameCocina1=Frame()
    FrameCocina1.pack(fill=BOTH, expand=True)
    FotoFondoCocina1=cargarImagen("CocinaVoladora.png")
    FotoFondoCocina1=FotoFondoCocina1.zoom(1,1)
    LabelFondoCpcina1=Label(FrameCocina1, image=FotoFondoCocina1)
    LabelFondoCpcina1.place(relx=0.5, rely=0.5, anchor="center")
    LabelFondoCpcina1.lower()
    LabelFondoCpcina1.image=FotoFondoCocina1

    CocinaVolador = Cocina(tiempo=150, escenario=1, players=[], ordenes=[])
    
    def pantallaTiempoAcabado():
        def FuncionBotonRegresar(): #Funcion que regresa al frame de elegir mapa y suma los puntos a los puntosAcumulados
            import Interfaz_grafica_inicio
            Interfaz_grafica_inicio.PuntosAcumulados += Jugador1.puntos  # Modifica la variable la original 
            Jugador1.puntos = 0 #reinicia los puntos para que se inicie una partida sin puntos
            from InterfazGraficaSelectMap import pantallaDeSeleccionMap
            FrameCocina1.pack_forget()
            ventanaMap1.destroy()
            pantallaDeSeleccionMap()

        #Se crea la ventana que aparecera cuando acabe el tiempo
        ventanaMap1=Tk()
        ventanaMap1.title("El tiempo se ha acabado!")
        ventanaMap1.geometry("200x350")
        ventanaMap1.config(bg="light green")
        ventanaMap1.resizable(width=NO, height=NO)
        MensajeTiempoAcabado=Label(ventanaMap1, text=(f"El tiempo de la partina\nha finalizado!\nPuntos Obtenidos: {Jugador1.puntos}"))
        MensajeTiempoAcabado.place(relx=0.5, rely=0.4, anchor="center")
        MensajeTiempoAcabado.config(bg="light green")
        botonRegresarAlMapa=Button(ventanaMap1, text=("Regresar al mapa"), command=FuncionBotonRegresar)
        botonRegresarAlMapa.place(relx=0.5, rely=0.8, anchor="center")
    
    """----------------------------------------------------------------------------------"""

    def ContarTiempo(): #Un contador que va disminuyendo el tiempo de partida
        tiempoActual=CocinaVolador.getTiempo() #Se llama al metodo de obtener el tiempo de la cocina 
        tiempoActual=tiempoActual-1 #Resta uno al tiempo
        CocinaVolador.setTiempo(tiempoActual) #Y  se le agrega el resultado anterior al tiempo de la cocina
        LabelTiempoRestantePantalla.config(text=f"Tiempo Restante: {tiempoActual}") #Esto actualiza el tiempo en pantalla
        if tiempoActual > 0:
            FrameCocina1.after(1000, ContarTiempo)
        else:
            pantallaTiempoAcabado()
            
    """-----------------------------------------------------------------------------------"""
    #Creamos un frame que se muestre en la pantalla para que el jugador vea las recetas
    labelRecetas = Label(FrameCocina1, text="", bg="white", font=("Arial", 10))
    labelRecetas.place(x=350, y=0)
    def mostrarRecetas():
        #Aqui muestra el nombre de los ingredinetes a ocupar recorriendo con un for la lista de  los ingredientes del objeto Cocina
        texto="Recetas por Hacer:"
        for orden in CocinaVolador.ordenes:
            nombres=[ing.nombre for ing in orden.listaIngredientes]
            texto+= " | " + ", ".join(nombres)
        labelRecetas.config(text=texto)

    def generarRecetaAleatoria():
        #Aqui se generan las recetas aleatorias
        CocinaVolador.generaReceta()
        mostrarRecetas()  # actualiza lo visual
        if CocinaVolador.getTiempo() > 0:
            FrameCocina1.after(15000, generarRecetaAleatoria)
    generarRecetaAleatoria()
    """-----------------------------------------------------------------------------------"""
    
    #Esto es un Label que mostrara el tiempo restante en panatalla
    LabelTiempoRestantePantalla=Label(FrameCocina1, text="", bg="grey")
    LabelTiempoRestantePantalla.place(x=1050, y=0)
    LabelTiempoRestantePantalla.config(text=f"Tiempo Restante: {CocinaVolador.getTiempo()}")

    #Este es para mostrar los puntos que se van obteniendo durante la partida!
    LabelMostrarPuntos = Label(FrameCocina1, text="Puntos: 0", bg="grey")
    LabelMostrarPuntos.place(x=1050, y=20)
    def actualizarPuntos(): 
        LabelMostrarPuntos.config(text=f"Puntos: {Jugador1.puntos}")
    """-----------------------------------------------------------------------------------"""
    
    """Objetos personajes"""
    from Interfaz_grafica_inicio import Jugador1 
    from Interfaz_grafica_inicio import Jugador2
    #Posicion e imagenes del jugador 1
    imgJugador1 = cargarImagen("personaje1abajo.gif")
    Jugador1.setX(600) 
    Jugador1.setY(350)
    Jugador1Label= Label(FrameCocina1, image=imgJugador1)
    Jugador1Label.place(x=Jugador1.x, y=Jugador1.y)
    Jugador1Label.image=imgJugador1
    Jugador1Label.lift()
    #Posicion e imagenes del jugador 2
    imgJugador2 = cargarImagen("personaje2abajo.gif")
    Jugador2.setX(700)
    Jugador2.setY(350)
    Jugador2Label = Label(FrameCocina1, image=imgJugador2)
    Jugador2Label.place(x=Jugador2.x, y=Jugador2.y)
    Jugador2Label.image = imgJugador2
    Jugador2Label.lift()

    jugadorActivo=Jugador1#Se crea una variable para que sea el jugador activo

    #Esto se encargara de poder observar que se posee en la mano:
    FrameEnMano=Frame(FrameCocina1, bg="brown", width=80, height=80) #Se crea el frame en donde se vera el objeto sostenido
    FrameEnMano.place(x=0,y=0)
    FrameEnMano.pack_propagate(False) 
    labelEnMano=Label(FrameEnMano, bg="brown") #Se crea la etiqueta
    labelEnMano.place(x=0, y=0)
    labelEnMano.pack(expand=True)
    def actualizarMano(jugador): 
        #Luego se crea la funcion que actualiza la imagen del objeto sostenido 
        if jugador.Ingrediente is not None: #Si tiene algo, pasa:
            estado = "True" if jugador.Ingrediente.estado else "False" #Verifica el estado del objeto
            nuevaImg = cargarImagenMaterial(f"{jugador.Ingrediente.nombre}{estado}.png") #Lo compara con las imagenes y escoge la indicada
            labelEnMano.config(image=nuevaImg)
            labelEnMano.image = nuevaImg
            FrameEnMano.image=nuevaImg
        else: #Si no, no se pone inguna imagen
            labelEnMano.config(image="")
            labelEnMano.image = None

    def interactuar(jugador):
        #Esta funcion se encarga de interactuar con las estaciones que se encuentran en el nivel
        todasLasEstaciones=[ #Primero se crea una lista que contenga las estaciones del nivel
            freidora, tablaDePicar, estCocina, mostrador, Dis_Arroz,
            Dis_Pollo, Dis_Tomate, Dis_Frijoles, Dis_Platano, Dis_Papa
        ]
        for estacion in todasLasEstaciones:
            print(f"Revisando {estacion.nombre} - distancia x:{abs(jugador.x - estacion.x)} y:{abs(jugador.y - estacion.y)}")
    
            # Verifica cercanía según la dirección que mira el jugador
            cercano = False
            if jugador.face == "izquierda" and estacion.x < jugador.x:
                if abs(jugador.x - estacion.x) < 100 and abs(jugador.y - estacion.y) < 80:
                    cercano = True
            elif jugador.face == "derecha" and estacion.x > jugador.x :
                if abs(jugador.x - estacion.x) < 100 and abs(jugador.y - estacion.y) < 80:
                    cercano = True
            elif jugador.face == "arriba" and estacion.y < jugador.y:
                if abs(jugador.y - estacion.y) < 100 and abs(jugador.x - estacion.x) < 80:
                    cercano = True
            elif jugador.face == "abajo" and estacion.y > jugador.y:
                if abs(jugador.y - estacion.y) < 100 and abs(jugador.x - estacion.x) < 80:
                    cercano = True

            if not cercano:
                continue  # Si no está cerca ni mirando, sigue con la siguiente estación

            print(f"Cerca de {estacion.nombre}")
    
            if "Dis_" in estacion.nombre:
                #Si la estacion en su nombre posee Dis_ es pq es un dispensador, por ende ototrga un objeto
                ingredientes = estacion.dispensador()
                jugador.UnIngrediente(ingredientes)

            elif estacion.nombre in ["estCocina", "tablaDePicar", "freidora"]:
                #De lo contrario si se llama como uno de los tres en la lista, procesa el ingrediente que se tiene en la mano
                if jugador.Ingrediente is not None:
                    estacion.Ingrediente = jugador.Ingrediente
                    estacion.procesarIngredientes()
                    jugador.soltarIngrediente()
                    print("Ingrediente dejado en estacion!")
                elif estacion.Ingrediente is not None and estacion.Ingrediente.estado == True:
                    #Si tiene las manos vacías y la estación tiene algo ya listo, lo recoge
                    jugador.UnIngrediente(estacion.Ingrediente)
                    estacion.Ingrediente = None
                    print("Ingrediente recogido!")
                else:
                    return 
                print ("No hay nada aquí")
            elif estacion.nombre == "mostrador":
                #Si se llama mostrador, se agrega el objeto en la mano y se compara con una de las listas activas en el momento
                if jugador.Ingrediente is not None:
                    estacion.Ingrediente = jugador.Ingrediente
                    estacion.aceptados = CocinaVolador.ordenes  # usa las ordenes activas
                    puntos = estacion.mostradorDeComidas()
                    Jugador1.puntos += puntos
                    jugador.soltarIngrediente()
                    mostrarRecetas()
                    actualizarPuntos()
            actualizarMano(jugador)
            break
            

    def moverJugador(event): #Esta funcion se encarga de mover al jugador por el mapa
        nonlocal jugadorActivo
        #Estos condicionales determinan cual jugador se va a usar dependiendo si se clickea la tecla q
        tecla=event.keysym.lower()
        if tecla=="q": #Cambie de personaje
            jugadorActivo=Jugador2 if jugadorActivo==Jugador1 else Jugador1
            return
        
        elif tecla=="r": #suelta el ingrediente
            jugadorActivo.soltarIngrediente()
            actualizarMano(jugadorActivo)
            return

        elif tecla=="e": #Con la letra e, se interactua en la cocina, llamando a la funcion interactuar
            interactuar(jugadorActivo)
            return 

        jugadorActivo.mover(event)

        if jugadorActivo == Jugador1: #Si el persoanje activo es el jugador 1, se utilizan los siguientes comandos
            nuevaImagen = cargarImagen(f"personaje1{Jugador1.face}.gif")
            Jugador1Label.config(image=nuevaImagen)
            Jugador1Label.image = nuevaImagen
            Jugador1Label.place(x=Jugador1.x, y=Jugador1.y)
        else: #De lo contrario, si es el 2, se utilizan los comandos siguientes
            nuevaImagen = cargarImagen(f"personaje2{Jugador2.face}.gif")
            Jugador2Label.config(image=nuevaImagen)
            Jugador2Label.image = nuevaImagen
            Jugador2Label.place(x=Jugador2.x, y=Jugador2.y)
        
    FrameCocina1.bind("<Key>", moverJugador)
    FrameCocina1.focus_set()     

    """-----------------------------------------------------------------------------------"""
    """En otras palabras, lo que se muestra de aqui en adelante son las interfaces graficas de los objetos"""
    
    """Objetos Estaciones:"""

    from Clases_y_objetos import freidora
    imgFreidora=cargarImagen("EstacionFreidora.png")
    imgFreidora=imgFreidora.subsample(8,8)
    freidoraLabel=Label(FrameCocina1, image=imgFreidora)
    freidoraLabel.place(x=675, y=110)
    freidora.setX(675)
    freidora.setY(110)
    freidoraLabel.image=imgFreidora

    from Clases_y_objetos import tablaDePicar
    imgTablaDePicar=cargarImagen("EstacionTablaDePicar.png")
    imgTablaDePicar=imgTablaDePicar.subsample(4,4)
    tablaDePicarLabel=Label(FrameCocina1, image=imgTablaDePicar)
    tablaDePicarLabel.place(x=450, y=120)
    tablaDePicar.setX(450)
    tablaDePicar.setY(120)
    tablaDePicarLabel.image=imgTablaDePicar

    from Clases_y_objetos import estCocina
    imgEstCocina=cargarImagen("EstacionCocina.png")
    imgEstCocina=imgEstCocina.subsample(2,2)
    estCocinaLabel=Label(FrameCocina1, image=imgEstCocina)
    estCocinaLabel.place(x=275,y=350)
    estCocina.setX(275)
    estCocina.setY(350)
    estCocinaLabel.image=imgEstCocina

    from Clases_y_objetos import mostrador, RecetasRestauranteVolador
    mostrador.aceptados = RecetasRestauranteVolador
    imgMostrador=cargarImagen("EstacionMostrador.png")
    imgMostrador=imgMostrador.subsample(3,3)
    mostradorLabel=Label(FrameCocina1, image=imgMostrador)
    mostradorLabel.place(x=1050,y=350)
    mostrador.setX(1050)
    mostrador.setY(350)
    mostradorLabel.image=imgMostrador 

    """Estaciones para recoger ingredientes"""

    from Clases_y_objetos import Dis_Arroz
    imgDis_Arroz=cargarImagenMaterial("arrozFalse.png")
    imgDis_Arroz= imgDis_Arroz.zoom(1,1)
    Dis_ArrozLabel=Label(FrameCocina1, image=imgDis_Arroz)
    Dis_ArrozLabel.place(x=100, y=550)
    Dis_Arroz.setX(100)
    Dis_Arroz.setY(550)
    Dis_ArrozLabel.image=imgDis_Arroz
    prepararArroz=Label(FrameCocina1, text="cocinar")
    prepararArroz.place(x=100, y=650)

    from Clases_y_objetos import Dis_Pollo
    imgDis_Pollo = cargarImagenMaterial("polloFalse.png")
    imgDis_Pollo = imgDis_Pollo.subsample(2,2)
    Dis_PolloLabel = Label(FrameCocina1, image=imgDis_Pollo)
    Dis_PolloLabel.place(x=200, y=550)
    Dis_Pollo.setX(200)
    Dis_Pollo.setY(550)
    Dis_PolloLabel.image = imgDis_Pollo
    PrepararPollo=Label(FrameCocina1, text="Freir")
    PrepararPollo.place(x=200, y=650)

    from Clases_y_objetos import Dis_Tomate
    imgDis_Tomate = cargarImagenMaterial("tomateFalse.png")
    imgDis_Tomate = imgDis_Tomate.subsample(2,2)
    Dis_TomateLabel = Label(FrameCocina1, image=imgDis_Tomate)
    Dis_TomateLabel.place(x=300, y=550)
    Dis_Tomate.setX(300)
    Dis_Tomate.setY(550)
    Dis_TomateLabel.image = imgDis_Tomate
    prepararTomate=Label(FrameCocina1, text="cortar")
    prepararTomate.place(x=300, y=650)

    from Clases_y_objetos import Dis_Frijoles
    imgDis_Frijoles = cargarImagenMaterial("frijolesFalse.png")
    Dis_FrijolesLabel = Label(FrameCocina1, image=imgDis_Frijoles)
    Dis_FrijolesLabel.place(x=400, y=550)
    Dis_Frijoles.setX(400)
    Dis_Frijoles.setY(550)
    Dis_FrijolesLabel.image = imgDis_Frijoles
    prepararFrijoles=Label(FrameCocina1, text="cortar")
    prepararFrijoles.place(x=400, y=650)

    from Clases_y_objetos import Dis_Platano
    imgDis_Platano = cargarImagenMaterial("platanoFalse.png")
    imgDis_Platano = imgDis_Platano.subsample(2,2)
    Dis_PlatanoLabel = Label(FrameCocina1, image=imgDis_Platano)
    Dis_PlatanoLabel.place(x=800, y=550)
    Dis_Platano.setX(800)
    Dis_Platano.setY(550)
    Dis_PlatanoLabel.image = imgDis_Platano
    prepararPlatano=Label(FrameCocina1, text="cortar")
    prepararPlatano.place(x=800, y=650)

    from Clases_y_objetos import Dis_Papa
    imgDis_Papa = cargarImagenMaterial("papaFalse.png")
    imgDis_Papa = imgDis_Papa.subsample(2,2)
    Dis_PapaLabel = Label(FrameCocina1, image=imgDis_Papa)
    Dis_PapaLabel.place(x=700, y=550)
    Dis_Papa.setX(700)
    Dis_Papa.setY(550)
    Dis_PapaLabel.image = imgDis_Papa
    prepararPapa=Label(FrameCocina1, text="cocinar")
    prepararPapa.place(x=700, y=650)

    """-----------------------------------------------------------------------------------"""
    ContarTiempo() #Esto sigue llamando a la funcion de contador ya que se sin importar lo que pase, el tiempo avanza
    