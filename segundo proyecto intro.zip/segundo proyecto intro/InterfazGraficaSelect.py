from tkinter import *
import os
from Clases_y_objetos import * 

"""-----------------------------------------------------------------------------------------"""

def cargarImagen(nombre):
    #Esta funcion se encargara de crear una ruta para la imagen de fonfo para la pantalla de inicio
    ruta=os.path.join("imagenes",  nombre)
    imagen=PhotoImage(file=ruta)
    return imagen

"""-----------------------------------------------------------------------------------------"""

def pantallaDeSeleccionPersonaje():
    PerFrame=Frame() #Crea un nuevo frame 
    PerFrame.pack(fill=BOTH, expand=True) #Expande el frame para que se pueda ver en pantalla
    
    fotoFondo=cargarImagen("FondoSeleccionPersonaje.png") #Carga la images desde la ruta creada al inicio
    fotoFondo=fotoFondo.zoom(1, 1)  # agranda la imagen al doble
    labelFondo=Label(PerFrame, image=fotoFondo) #crea la imagen como una especie de etiqueta
    labelFondo.place(x=0, y=0) #Posiciona la imagen
    labelFondo.lower()
    labelFondo.image = fotoFondo 
    
    #Fotos de personajes
    FotoPlayer1=cargarImagen("personaje1abajo.gif")
    FotoPlayer1=FotoPlayer1.zoom(2, 2)
    labelPersonaje1=Label(PerFrame, image=FotoPlayer1)
    labelPersonaje1.place(relx=0.3, rely=0.5, anchor="center")
    labelPersonaje1.image=FotoPlayer1 
    FotoPlayer2=cargarImagen("personaje2abajo.gif")
    FotoPlayer2=FotoPlayer2.zoom(2, 2)
    labelPersonaje2=Label(PerFrame, image=FotoPlayer2)
    labelPersonaje2.place(relx=0.7, rely=0.5, anchor="center")
    labelPersonaje2.image=FotoPlayer2

    #botones para personajes
    def botonPlayer1():
        pass
    BotonPlayer1=Button(PerFrame, text="Player 1", command=botonPlayer1)
    BotonPlayer1.place(relx=0.3, rely=0.8, anchor="center")
    def botonPlayer2():
        pass
    BotonPlayer1=Button(PerFrame, text="Player 2", command=botonPlayer2)
    BotonPlayer1.place(relx=0.7, rely=0.8, anchor="center")
